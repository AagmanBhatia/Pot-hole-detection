# pothole-detection > 2024-04-17 4:24am
https://universe.roboflow.com/potholedetection-jzmyt/pothole-detection-smyqm

Provided by a Roboflow user
License: CC BY 4.0

